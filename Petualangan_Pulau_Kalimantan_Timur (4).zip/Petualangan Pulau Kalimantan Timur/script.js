/**
 * Petualangan Kalimantan Timur - Interactive Adventure Map Engine
 * Vanilla JavaScript (No Frameworks, No Backend, 100% Browser Native)
 */

document.addEventListener('DOMContentLoaded', () => {
  // ============================================================
  // 1. DATA DESTINASI BUDAYA KALIMANTAN TIMUR
  // ============================================================
  const DESTINATIONS = [
    {
      id: 1,
      title: "Rumah Lamin",
      category: "Rumah Adat Dayak",
      image: "assets/rumah-lamin.png",
      description: "Rumah Lamin merupakan rumah adat masyarakat Dayak di Kalimantan Timur. Rumah ini berbentuk rumah panjang dan menjadi simbol kehidupan bersama di masyarakat.",
      hasAudio: false,
      isLively: false
    },
    {
      id: 2,
      title: "Mandau",
      category: "Senjata Tradisional Pusaka",
      image: "assets/mandau.png",
      description: "Mandau adalah senjata tradisional khas masyarakat Dayak di Kalimantan, termasuk Kalimantan Timur. Mandau terdiri dari bilah yang panjang dan tajam, hulu sebagai gagang, serta kumpang sebagai sarungnya. Bagian hulu biasanya dihiasi ukiran khas Dayak. Selain sebagai senjata, mandau juga menjadi simbol keberanian, kehormatan, dan identitas budaya masyarakat Dayak.",
      hasAudio: false,
      isLively: false
    },
    {
      id: 3,
      title: "Tameng",
      category: "Perisai Tradisional Telabang",
      image: "assets/tameng.png",
      description: "Tameng merupakan alat pelindung tradisional masyarakat Dayak di Kalimantan yang digunakan untuk melindungi diri dari serangan. Tameng biasanya terbuat dari kayu yang kuat dan dihiasi dengan ukiran atau motif khas Dayak. Selain sebagai pelindung, tameng juga menjadi simbol keberanian, kekuatan, dan identitas budaya masyarakat Dayak.",
      hasAudio: false,
      isLively: false
    },
    {
      id: 4,
      title: "Tari Gantar",
      category: "Seni Tari Tradisional",
      image: "assets/tari-gantar.png",
      description: "Tari Gantar adalah tarian tradisional khas Kalimantan Timur yang berasal dari masyarakat Dayak. Tarian ini menggambarkan kegiatan menanam padi dan menjadi ungkapan rasa syukur atas hasil pertanian. Gerakannya menggunakan bambu dan tongkat sebagai properti, yang melambangkan kegiatan bercocok tanam. Tari Gantar juga mencerminkan kebersamaan, kegembiraan, dan kehidupan masyarakat Dayak.",
      hasAudio: false,
      isLively: true // Animasi gerakan hidup
    },
    {
      id: 5,
      title: "Lagu Indung-Indung",
      category: "Lagu Daerah Kalimantan Timur",
      image: "assets/indung-indung.png",
      description: "Indung-Indung merupakan lagu tradisional khas Kalimantan Timur yang berasal dari masyarakat Kutai. Lagu ini memiliki nuansa lembut dan berisi nasihat serta pesan moral, terutama tentang kehidupan, sopan santun, dan nilai-nilai kebaikan.",
      hasAudio: true, // Pemutar musik & audio
      isLively: false
    },
    {
      id: 6,
      title: "Kuliner Khas Kalimantan Timur",
      category: "Makanan Daerah",
      image: "assets/kuliner-khas.png",
      description: "Kalimantan Timur memiliki beragam kuliner khas, seperti Gangan Manok, Ayam Cincane, Pisang Gapit, dan Teh Bajakah.",
      hasAudio: false,
      isLively: false
    },
    {
      id: 7,
      title: "Asal Mula Kota Balikpapan",
      category: "Cerita Rakyat",
      image: "assets/balikpapan.png",
      description: "Nama Balikpapan memiliki cerita asal-usul yang diwariskan secara turun-temurun. Tonton video berikut untuk mengetahui kisah di balik nama kota Balikpapan.",
      hasAudio: false,
      hasVideo: true, // Pemutar video asal-usul
      isLively: false
    }
  ];

  // Jumlah destinasi dihitung otomatis dari data di atas,
  // sehingga menambah destinasi baru tidak perlu mengubah angka lain.
  const TOTAL = DESTINATIONS.length;     // 7
  const FINISH_STEP = TOTAL + 1;         // 8 (gerbang SELESAI)

  // Koordinat dibaca langsung dari posisi landmark di peta SVG,
  // jadi selalu sinkron dengan index.html.
  function getNodeCoords(id) {
    const el = document.getElementById(id);
    const m = el && (el.getAttribute('transform') || '').match(/translate\(\s*([-\d.]+)[ ,]+([-\d.]+)\s*\)/);
    return m ? { x: parseFloat(m[1]), y: parseFloat(m[2]) } : { x: 0, y: 0 };
  }
  const START_COORDS = getNodeCoords('nodeStart');
  DESTINATIONS.forEach(d => { d.targetCoords = getNodeCoords('nodeDest' + d.id); });

  // ============================================================
  // 2. STATE VARIABEL
  // ============================================================
  let currentStep = 0; // 0 = START, 1..TOTAL = Destinasi, TOTAL+1 = FINISH
  let completedDestinations = new Set();
  let isMoving = false;
  let soundEnabled = true;

  // Audio Context untuk Web Audio API (Melodi Lagu & SFX)
  let audioCtx = null;
  let isSongPlaying = false;
  let songInterval = null;
  let songNoteIndex = 0;

  // ============================================================
  // 3. DOM ELEMENTS
  // ============================================================
  const adventurePath = document.getElementById('adventurePath');
  const characterParty = document.getElementById('characterParty');
  const partySprites = document.getElementById('partySprites');
  const progressText = document.getElementById('progressText');
  const progressDots = document.querySelectorAll('.progress-dots .dot');
  const guideText = document.getElementById('guideText');
  const btnMainAction = document.getElementById('btnMainAction');
  const mainActionText = document.getElementById('mainActionText');
  const btnSound = document.getElementById('btnSound');
  const soundIcon = document.getElementById('soundIcon');
  const btnResetHeader = document.getElementById('btnResetHeader');
  const audioPlayer = document.getElementById('audioPlayer');

  // Modal Destinasi
  const destinationModal = document.getElementById('destinationModal');
  const modalStepBadge = document.getElementById('modalStepBadge');
  const modalImg = document.getElementById('modalImg');
  const modalTitle = document.getElementById('modalTitle');
  const modalText = document.getElementById('modalText');
  const showcaseSparkles = document.getElementById('showcaseSparkles');
  const audioPlayerWidget = document.getElementById('audioPlayerWidget');
  const btnPlayAudio = document.getElementById('btnPlayAudio');
  const playIcon = document.getElementById('playIcon');
  const playText = document.getElementById('playText');
  const soundWave = document.getElementById('soundWave');
  const btnModalContinue = document.getElementById('btnModalContinue');
  const btnModalContinueText = document.getElementById('btnModalContinueText');

  // Modal Final
  const finalModal = document.getElementById('finalModal');
  const btnRestartFinal = document.getElementById('btnRestartFinal');
  const confettiCanvas = document.getElementById('confettiCanvas');

  // Landmark DOM nodes
  const landmarkNodes = { 0: document.getElementById('nodeStart') };
  DESTINATIONS.forEach(d => { landmarkNodes[d.id] = document.getElementById('nodeDest' + d.id); });
  landmarkNodes[FINISH_STEP] = document.getElementById('nodeFinish');

  // Video destinasi (Asal Mula Balikpapan)
  const modalShowcase = document.getElementById('modalShowcase');
  const showcaseImgWrap = document.getElementById('showcaseImgWrap');
  const showcaseVideoWrap = document.getElementById('showcaseVideoWrap');
  const destinationVideo = document.getElementById('destinationVideo');

  const roadmapItems = document.querySelectorAll('.roadmap-item');

  // ============================================================
  // 4. PATH DISTANCE CALCULATIONS (getPointAtLength)
  // ============================================================
  let pathWaypoints = {};

  function initPathWaypoints() {
    if (!adventurePath) return;
    const totalLength = adventurePath.getTotalLength();

    // Fungsi helper untuk menemukan jarak terdekat pada path terhadap koordinat (x, y)
    function findDistanceAlongPath(targetX, targetY) {
      let bestDist = 0;
      let minDelta = Infinity;
      const precision = 600; // 600 sample points sepanjang kurva jalan
      for (let i = 0; i <= precision; i++) {
        const d = (i / precision) * totalLength;
        const pt = adventurePath.getPointAtLength(d);
        const delta = Math.hypot(pt.x - targetX, pt.y - targetY);
        if (delta < minDelta) {
          minDelta = delta;
          bestDist = d;
        }
      }
      return bestDist;
    }

    pathWaypoints[0] = 0; // START
    DESTINATIONS.forEach(dest => {
      pathWaypoints[dest.id] = findDistanceAlongPath(dest.targetCoords.x, dest.targetCoords.y);
    });
    pathWaypoints[FINISH_STEP] = totalLength; // FINISH

    // Tempatkan karakter awal di START
    setPartyPosition(START_COORDS.x, START_COORDS.y, 1);
  }

  function setPartyPosition(x, y, scaleX = 1) {
    if (!characterParty) return;
    characterParty.setAttribute('transform', `translate(${x}, ${y})`);
    if (partySprites) {
      partySprites.setAttribute('transform', `scale(${scaleX}, 1)`);
    }
  }

  // ============================================================
  // 5. AUDIO & SOUND EFFECTS (Web Audio API Synthesizer)
  // ============================================================
  function getAudioContext() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  // Nada lembut langkah kaki saat karakter berjalan
  function playStepSound() {
    if (!soundEnabled) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140 + Math.random() * 40, ctx.currentTime);

      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch (e) {
      // Ignore audio error
    }
  }

  // Chime gembira saat sampai di destinasi
  function playArriveSound() {
    if (!soundEnabled) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // Arpeggio chord gembira (Do - Mi - Sol - Do)
      const freqs = [523.25, 659.25, 783.99, 1046.50];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0, now + idx * 0.1);
        gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.1 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.5);
      });
    } catch (e) {
      // Ignore
    }
  }

  // Fanfare kemenangan saat petualangan selesai
  function playVictorySound() {
    if (!soundEnabled) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const melody = [
        { f: 523.25, d: 0.18 },
        { f: 659.25, d: 0.18 },
        { f: 783.99, d: 0.18 },
        { f: 1046.50, d: 0.45 },
        { f: 880.00, d: 0.22 },
        { f: 1046.50, d: 0.7 }
      ];

      let t = now;
      melody.forEach(item => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(item.f, t);

        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.16, t + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, t + item.d);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + item.d);
        t += item.d;
      });
    } catch (e) {
      // Ignore
    }
  }

  // Melodi Tradisional Lagu Daerah "Indung-Indung" (Kalimantan Timur)
  // Notasi Sape / Marimba yang merdu
  const INDUNG_INDUNG_MELODY = [
    // "In-dung in-dung ke-pa-la lin-dung"
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 392.00, dur: 0.50 }, // Sol
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 440.00, dur: 0.32 }, // La
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 329.63, dur: 0.65 }, // Mi

    // "Hu-jan di u-dik di si-ni men-dung"
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 293.66, dur: 0.32 }, // Re
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 349.23, dur: 0.50 }, // Fa
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 293.66, dur: 0.65 }, // Re

    // "A-nak sia-pa pa-kai ke-ru-dung"
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 392.00, dur: 0.50 }, // Sol
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 440.00, dur: 0.32 }, // La
    { note: 392.00, dur: 0.32 }, // Sol
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 329.63, dur: 0.65 }, // Mi

    // "Ma-ta me-li-rik ka-ki ter-san-dung"
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 293.66, dur: 0.32 }, // Re
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 349.23, dur: 0.45 }, // Fa
    { note: 349.23, dur: 0.32 }, // Fa
    { note: 329.63, dur: 0.32 }, // Mi
    { note: 293.66, dur: 0.32 }, // Re
    { note: 261.63, dur: 0.45 }, // Do
    { note: 261.63, dur: 0.70 }  // Do
  ];

  // ------------------------------------------------------------
  // BACKSOUND LATAR
  // Menyala otomatis saat web dibuka. Mati sementara saat lagu
  // Indung-Indung atau video Asal Mula Balikpapan sedang diputar,
  // lalu menyala lagi setelah selesai / dijeda / modal ditutup.
  // ------------------------------------------------------------
  const bgmPlayer = document.getElementById('bgmPlayer');
  const BGM_VOLUME = 0.35;
  let isVideoPlaying = false;
  let bgmFadeTimer = null;

  function fadeBgm(target, onDone) {
    if (!bgmPlayer) return;
    clearInterval(bgmFadeTimer);
    bgmFadeTimer = setInterval(() => {
      const diff = target - bgmPlayer.volume;
      if (Math.abs(diff) <= 0.03) {
        bgmPlayer.volume = target;
        clearInterval(bgmFadeTimer);
        if (onDone) onDone();
      } else {
        bgmPlayer.volume = Math.min(1, Math.max(0, bgmPlayer.volume + Math.sign(diff) * 0.03));
      }
    }, 40);
  }

  function updateBgm() {
    if (!bgmPlayer) return;
    const shouldPlay = soundEnabled && !isSongPlaying && !isVideoPlaying && !document.hidden;
    if (shouldPlay) {
      if (bgmPlayer.paused) {
        bgmPlayer.volume = 0;
        const p = bgmPlayer.play();
        if (p !== undefined) p.catch(() => { /* diblokir browser: dicoba lagi saat klik pertama */ });
      }
      fadeBgm(BGM_VOLUME);
    } else if (!bgmPlayer.paused) {
      fadeBgm(0, () => bgmPlayer.pause());
    }
  }

  // Coba langsung putar saat web dibuka. Kalau browser memblokir
  // autoplay, backsound dimulai otomatis pada interaksi pertama (klik/tap/tombol).
  if (bgmPlayer) {
    bgmPlayer.volume = 0;
    updateBgm();
    const unlockBgm = () => {
      updateBgm();
      if (!bgmPlayer.paused) {
        ['pointerdown', 'keydown', 'touchstart'].forEach(ev => document.removeEventListener(ev, unlockBgm, true));
      }
    };
    ['pointerdown', 'keydown', 'touchstart'].forEach(ev => document.addEventListener(ev, unlockBgm, true));
    document.addEventListener('visibilitychange', updateBgm);
  }

  function togglePlayIndungIndung() {
    if (isSongPlaying) {
      stopIndungIndung();
    } else {
      startIndungIndung();
    }
  }

  function startIndungIndung() {
    isSongPlaying = true;
    updateBgm();
    btnPlayAudio.classList.add('playing');
    playIcon.textContent = '⏸';
    playText.textContent = 'Jeda Lagu';
    soundWave.classList.add('animating');

    if (audioPlayer) {
      if (!audioPlayer.src || !audioPlayer.src.includes('indung-indung.mp3')) {
        audioPlayer.src = 'assets/indung-indung.mp3';
      }
      audioPlayer.muted = !soundEnabled;
      const playPromise = audioPlayer.play();
      if (playPromise !== undefined) {
        playPromise.catch(err => {
          console.warn('Playback error or blocked by autoplay policy:', err);
        });
      }
      audioPlayer.onended = () => {
        stopIndungIndung();
      };
    }
  }

  function stopIndungIndung() {
    isSongPlaying = false;
    updateBgm();
    if (audioPlayer) {
      audioPlayer.pause();
    }
    if (btnPlayAudio) {
      btnPlayAudio.classList.remove('playing');
    }
    if (playIcon) playIcon.textContent = '▶';
    if (playText) playText.textContent = 'Putar Lagu';
    if (soundWave) soundWave.classList.remove('animating');
  }

  // ============================================================
  // 6. ANIMASI BERJALAN MENGIKUTI JALAN SETAPAK (WALKING ENGINE)
  // ============================================================
  function walkToStep(targetStep, onComplete) {
    if (isMoving) return;
    if (targetStep === currentStep) return;

    isMoving = true;
    characterParty.classList.add('walking');
    btnMainAction.disabled = true;

    // Ambil jarak start dan target pada adventurePath
    const startDist = pathWaypoints[currentStep] || 0;
    const targetDist = pathWaypoints[targetStep] || 0;
    const distDelta = targetDist - startDist;

    // Durasi proporsional dengan jarak tempuh (min 1.6s, max 2.6s)
    const duration = Math.min(2600, Math.max(1600, Math.abs(distDelta) * 3.4));
    let startTime = null;
    let lastStepTime = 0;

    // Highlight rute aktif pada roadmap
    updateRoadmapUI(targetStep);

    // Easing kuadratik lembut
    function easeInOutQuad(t) {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }

    function animateWalk(timestamp) {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = easeInOutQuad(progress);

      const currentDist = startDist + distDelta * eased;
      const pt = adventurePath.getPointAtLength(currentDist);

      // Cek arah hadap karakter (moving right = scaleX(1), moving left = scaleX(-1))
      const lookahead = Math.min(currentDist + 3, adventurePath.getTotalLength());
      const ptNext = adventurePath.getPointAtLength(lookahead);
      const facing = (ptNext.x < pt.x - 0.2) ? -1 : 1;

      setPartyPosition(pt.x, pt.y, facing);

      // Mainkan efek suara langkah setiap 220ms
      if (timestamp - lastStepTime > 220) {
        playStepSound();
        lastStepTime = timestamp;
      }

      if (progress < 1) {
        requestAnimationFrame(animateWalk);
      } else {
        // Selesai berjalan sampai di titik tujuan!
        characterParty.classList.remove('walking');
        isMoving = false;
        currentStep = targetStep;
        btnMainAction.disabled = false;

        if (typeof onComplete === 'function') {
          onComplete();
        }
      }
    }

    requestAnimationFrame(animateWalk);
  }

  // ============================================================
  // 7. INTERAKSI DESTINASI & CARD INFORMASI
  // ============================================================
  function arriveAtDestination(destId) {
    // 1. Play sound
    playArriveSound();

    // 2. Mark destination as completed
    completedDestinations.add(destId);

    // 3. Update landmark node on map (zoom-in, glow, checkmark)
    const node = landmarkNodes[destId];
    if (node) {
      node.classList.add('visited', 'active', 'completed');
    }

    // 4. Update progress indicator (e.g. 1/7, 2/7)
    updateProgressUI();

    // 5. Open information card modal
    openDestinationModal(destId);
  }

  function openDestinationModal(destId) {
    const dest = DESTINATIONS.find(d => d.id === destId);
    if (!dest) return;

    modalStepBadge.textContent = `DESTINASI ${dest.id} / ${TOTAL}`;
    modalImg.src = dest.image;
    modalImg.alt = dest.title;
    modalTitle.textContent = dest.title;
    modalText.textContent = dest.description;

    // Atur animasi penari Tari Gantar (Destinasi 4)
    if (dest.isLively) {
      modalImg.classList.add('animate-sway');
      showcaseSparkles.style.display = 'block';
    } else {
      modalImg.classList.remove('animate-sway');
      showcaseSparkles.style.display = 'none';
    }

    // Atur tampilan video (Destinasi 7: Asal Mula Balikpapan)
    if (dest.hasVideo) {
      modalShowcase.classList.add('has-video');
      showcaseImgWrap.style.display = 'none';
      showcaseVideoWrap.style.display = 'block';
      showcaseSparkles.style.display = 'none';
    } else {
      modalShowcase.classList.remove('has-video');
      showcaseImgWrap.style.display = '';
      showcaseVideoWrap.style.display = 'none';
      stopDestinationVideo();
    }

    // Atur Audio Player Widget untuk Lagu Indung-Indung (Destinasi 5)
    if (dest.hasAudio) {
      audioPlayerWidget.classList.add('visible');
    } else {
      audioPlayerWidget.classList.remove('visible');
      stopIndungIndung();
    }

    // Atur teks tombol modal
    if (dest.id === TOTAL) {
      btnModalContinueText.textContent = "Selesaikan Petualangan 🏆";
    } else {
      btnModalContinueText.textContent = `Lanjutkan ke Destinasi ${dest.id + 1}`;
    }

    destinationModal.classList.add('open');
    destinationModal.setAttribute('aria-hidden', 'false');

    // Update narrative
    guideText.innerHTML = `Kamu telah sampai di <strong>${dest.title}</strong>! Baca informasi budaya di atas lalu tekan <strong>"Lanjutkan"</strong>.`;
  }

  if (destinationVideo) {
    ['play', 'playing'].forEach(ev => destinationVideo.addEventListener(ev, () => {
      isVideoPlaying = true;
      updateBgm();
    }));
    ['pause', 'ended'].forEach(ev => destinationVideo.addEventListener(ev, () => {
      isVideoPlaying = false;
      updateBgm();
    }));
  }

  function stopDestinationVideo() {
    if (destinationVideo && !destinationVideo.paused) {
      destinationVideo.pause();
    }
    isVideoPlaying = false;
    updateBgm();
  }

  function closeDestinationModal() {
    destinationModal.classList.remove('open');
    destinationModal.setAttribute('aria-hidden', 'true');
    stopIndungIndung();
    stopDestinationVideo();

    // Hilangkan pulse ring dari node yang baru selesai agar tidak silau terus
    if (landmarkNodes[currentStep]) {
      landmarkNodes[currentStep].classList.remove('active');
    }
  }

  // ============================================================
  // 8. FLOW NAVIGASI UTAMA (LANJUTKAN & MULAI PETUALANGAN)
  // ============================================================
  function handleMainAction() {
    if (isMoving) return;

    // Jika di awal (START), mulai ke destinasi 1
    if (currentStep === 0) {
      startStepTo(1);
    } 
    // Jika di destinasi 1..(TOTAL-1), lanjut ke destinasi berikutnya
    else if (currentStep >= 1 && currentStep < TOTAL) {
      startStepTo(currentStep + 1);
    } 
    // Jika di destinasi terakhir, jalan menuju FINISH!
    else if (currentStep === TOTAL) {
      finishAdventure();
    }
  }

  function startStepTo(targetStep) {
    if (isMoving) return;

    // Update narrative text
    const targetDest = DESTINATIONS.find(d => d.id === targetStep);
    const targetName = targetDest ? targetDest.title : "Tujuan Berikutnya";
    guideText.innerHTML = `Karakter sedang berjalan menyusuri rute menuju <strong>${targetName}</strong>...`;

    // Highlight node tujuan yang sedang didekati
    if (landmarkNodes[targetStep]) {
      landmarkNodes[targetStep].classList.add('active');
    }

    walkToStep(targetStep, () => {
      arriveAtDestination(targetStep);
    });
  }

  function finishAdventure() {
    guideText.innerHTML = `Karakter sedang menuju gerbang akhir petualangan Kalimantan Timur...`;

    walkToStep(FINISH_STEP, () => {
      playVictorySound();
      if (landmarkNodes[FINISH_STEP]) {
        landmarkNodes[FINISH_STEP].classList.add('active', 'completed');
      }
      guideText.innerHTML = `🎉 <strong>PETUALANGAN SELESAI!</strong> Kamu telah menjelajahi seluruh kekayaan budaya Kalimantan Timur!`;
      openFinalModal();
    });
  }

  // ============================================================
  // 9. FINAL CELEBRATION MODAL & CONFETTI
  // ============================================================
  function openFinalModal() {
    finalModal.classList.add('open');
    finalModal.setAttribute('aria-hidden', 'false');
    startConfetti();
  }

  function closeFinalModal() {
    finalModal.classList.remove('open');
    finalModal.setAttribute('aria-hidden', 'true');
    stopConfetti();
  }

  // Confetti Ringan Bertema Alam & Budaya Kalimantan (Emas, Hijau, Merah)
  let confettiAnimId = null;
  function startConfetti() {
    if (!confettiCanvas) return;
    const ctx = confettiCanvas.getContext('2d');
    const width = confettiCanvas.width = confettiCanvas.offsetWidth;
    const height = confettiCanvas.height = confettiCanvas.offsetHeight;

    const colors = ['#F59E0B', '#10B981', '#EF4444', '#FBBF24', '#3B82F6', '#EC4899'];
    const particles = [];
    for (let i = 0; i < 70; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height - height,
        r: Math.random() * 6 + 4,
        d: Math.random() * 2 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        tilt: Math.random() * 10 - 10,
        tiltAngleInc: (Math.random() * 0.07) + 0.05,
        tiltAngle: 0
      });
    }

    function draw() {
      ctx.clearRect(0, 0, width, height);
      particles.forEach(p => {
        p.tiltAngle += p.tiltAngleInc;
        p.y += (Math.cos(p.d) + 1 + p.r / 2) * 0.8;
        p.x += Math.sin(p.d);
        p.tilt = Math.sin(p.tiltAngle) * 12;

        ctx.beginPath();
        ctx.lineWidth = p.r / 2;
        ctx.strokeStyle = p.color;
        ctx.moveTo(p.x + p.tilt + p.r, p.y);
        ctx.lineTo(p.x + p.tilt, p.y + p.tilt + p.r);
        ctx.stroke();

        if (p.y > height) {
          p.x = Math.random() * width;
          p.y = -20;
        }
      });

      confettiAnimId = requestAnimationFrame(draw);
    }

    draw();
  }

  function stopConfetti() {
    if (confettiAnimId) {
      cancelAnimationFrame(confettiAnimId);
      confettiAnimId = null;
    }
  }

  // ============================================================
  // 10. RESET / MULAI LAGI ENGINE
  // ============================================================
  function resetAdventure() {
    stopIndungIndung();
    stopDestinationVideo();
    closeDestinationModal();
    closeFinalModal();

    currentStep = 0;
    completedDestinations.clear();
    isMoving = false;

    // Kembalikan karakter ke START
    setPartyPosition(START_COORDS.x, START_COORDS.y, 1);
    characterParty.classList.remove('walking');

    // Reset status visual landmark
    Object.keys(landmarkNodes).forEach(k => {
      const node = landmarkNodes[k];
      if (node) {
        node.classList.remove('active', 'completed');
        if (k !== '0') {
          node.classList.remove('visited');
        }
      }
    });

    if (landmarkNodes[0]) {
      landmarkNodes[0].classList.add('visited', 'completed');
    }

    // Reset progress UI
    updateProgressUI();
    updateRoadmapUI(0);

    // Reset narrative
    guideText.innerHTML = `Selamat datang di Bumi Etam! Tekan tombol <strong>"Mulai Petualangan"</strong> untuk mengajak karakter menjelajahi pesona Kalimantan Timur.`;
    mainActionText.textContent = "Mulai Petualangan";
  }

  // ============================================================
  // 11. UPDATE PROGRESS & ROADMAP UI
  // ============================================================
  function updateProgressUI() {
    const count = completedDestinations.size;
    progressText.textContent = `PETUALANGAN: ${count}/${TOTAL}`;

    progressDots.forEach(dot => {
      const step = parseInt(dot.getAttribute('data-step'), 10);
      dot.classList.remove('active', 'completed');
      if (completedDestinations.has(step)) {
        dot.classList.add('completed');
        dot.textContent = '✓';
      } else if (step === currentStep + 1) {
        dot.classList.add('active');
        dot.textContent = step;
      } else {
        dot.textContent = step;
      }
    });

    // Perbarui teks tombol aksi utama
    if (count === 0) {
      mainActionText.textContent = "Mulai Petualangan";
    } else if (count < TOTAL) {
      mainActionText.textContent = `Lanjut ke Destinasi ${count + 1}`;
    } else if (count === TOTAL && currentStep < FINISH_STEP) {
      mainActionText.textContent = "Selesaikan Petualangan 🏆";
    } else {
      mainActionText.textContent = "Petualangan Selesai 🎉";
    }
  }

  function updateRoadmapUI(activeStep) {
    roadmapItems.forEach(item => {
      const step = parseInt(item.getAttribute('data-step'), 10);
      item.classList.remove('active');
      if (step === activeStep) {
        item.classList.add('active');
      }
      if (step > 0 && step <= TOTAL && completedDestinations.has(step)) {
        item.classList.add('completed');
      } else if (step > 0 && !completedDestinations.has(step)) {
        item.classList.remove('completed');
      }
    });
  }

  // ============================================================
  // 12. EVENT LISTENERS
  // ============================================================
  // Tombol Aksi Utama (Mulai Petualangan / Lanjut)
  btnMainAction.addEventListener('click', () => {
    handleMainAction();
  });

  // Tombol "Lanjutkan" pada Modal Destinasi
  btnModalContinue.addEventListener('click', () => {
    closeDestinationModal();
    handleMainAction();
  });

  // Tombol "Mulai Lagi" pada Modal Final
  btnRestartFinal.addEventListener('click', () => {
    resetAdventure();
  });

  // Tombol "Mulai Ulang" pada Header
  btnResetHeader.addEventListener('click', () => {
    if (confirm("Mulai ulang petualangan dari titik START?")) {
      resetAdventure();
    }
  });

  // Tombol Toggle Audio Lagu Indung-Indung
  btnPlayAudio.addEventListener('click', () => {
    togglePlayIndungIndung();
  });

  // Tombol Mute / Suara Header
  btnSound.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    soundIcon.textContent = soundEnabled ? '🔊' : '🔇';
    btnSound.classList.toggle('muted', !soundEnabled);
    if (audioPlayer) {
      audioPlayer.muted = !soundEnabled;
    }
    if (!soundEnabled) {
      stopIndungIndung();
    }
    updateBgm();
  });

  // Klik pada Landmark Peta untuk Melihat Kembali Destinasi yang Sudah Terbuka
  DESTINATIONS.forEach(dest => {
    const node = landmarkNodes[dest.id];
    if (node) {
      node.addEventListener('click', () => {
        if (isMoving) return;
        // Jika sudah pernah dikunjungi, buka informasinya
        if (completedDestinations.has(dest.id)) {
          openDestinationModal(dest.id);
        } else if (dest.id === currentStep + 1) {
          // Jika destinasi berikutnya, langsung ajak karakter berjalan ke sana!
          startStepTo(dest.id);
        }
      });
    }
  });

  // Klik pada Roadmap Footer
  roadmapItems.forEach(item => {
    item.addEventListener('click', () => {
      if (isMoving) return;
      const step = parseInt(item.getAttribute('data-step'), 10);
      if (step > 0 && step <= TOTAL && completedDestinations.has(step)) {
        openDestinationModal(step);
      } else if (step === FINISH_STEP && currentStep === TOTAL) {
        finishAdventure();
      } else if (step === currentStep + 1 && step <= TOTAL) {
        startStepTo(step);
      }
    });
  });

  // Close modal when clicking overlay background
  destinationModal.addEventListener('click', (e) => {
    if (e.target === destinationModal) {
      closeDestinationModal();
    }
  });

  // ============================================================
  // 13. INISIALISASI AWAL
  // ============================================================
  initPathWaypoints();
  updateProgressUI();
  updateRoadmapUI(0);

  // ============================================================
  // 14. LAYAR SELAMAT DATANG
  // ============================================================
  const welcomeScreen = document.getElementById('welcomeScreen');
  const btnWelcomeStart = document.getElementById('btnWelcomeStart');

  if (welcomeScreen && btnWelcomeStart) {
    btnWelcomeStart.focus({ preventScroll: true });
    btnWelcomeStart.addEventListener('click', () => {
      // Klik pertama = interaksi pengguna, sekalian aktifkan audio browser
      getAudioContext();
      playArriveSound();
      welcomeScreen.classList.add('hide');
      welcomeScreen.setAttribute('aria-hidden', 'true');
      setTimeout(() => { welcomeScreen.style.display = 'none'; }, 800);
    });
  }
});
